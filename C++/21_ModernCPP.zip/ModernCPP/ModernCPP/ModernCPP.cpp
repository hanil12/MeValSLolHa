﻿#include <iostream>
#include <vector>
#include <unordered_map>
#include <algorithm>

using namespace std;

// 람다

int main()
{
	vector<int> v = { 2,3,54,1,3,5,25,23,222 };

	int compareNum = 100;
	int temp = 1;

	std::find_if(v.begin(), v.end(), [=](const int& element)->bool // [=] ... 내 위에 나와있는 변수들 전부 캡쳐
		{
			if (element > compareNum)
			{
				return true;
			}
			return false;
		});

	return 0;
}