#pragma once

template <typename T>
struct Node
{
	Node(const T& data)
		: data(data), next(nullptr), prev(nullptr) {}

	T data;
	Node<T>* next;
	Node<T>* prev;
};

template <typename T>
class MyList
{
public:
	class Iterator
	{
	public:
		Iterator() : _ptr(nullptr) {}
		Iterator(Node<T>* ptr) : _ptr(ptr) {}
		~Iterator() {}

		Iterator& operator++()
		{
			_ptr = _ptr->next;

			return *this;
		}

		Iterator operator++(int)
		{
			Iterator result = *this;

			_ptr = _ptr->next;

			return result;
		}

		bool operator==(const Iterator& other)
		{
			return _ptr == other._ptr;
		}

		bool operator!=(const Iterator& other)
		{
			return _ptr != other._ptr;
		}

		T& operator*()
		{
			return _ptr->data;
		}

	private:
		Node<T>* _ptr;
	};

	MyList()
	: _size(0)
	{
		_head = new Node<T>(T());
		_head->next = _head;
		_head->prev = _head;
	}

	~MyList()
	{
		Clear();

		delete _head;
	}

	void Push_Front(const T& value)
	{
		Node<T>* newNode = new Node<T>(value);
		
		Node<T>* prev = _head;
		Node<T>* next = _head->next;

		newNode->next = next;
		newNode->prev = prev;

		prev->next = newNode;
		next->prev = newNode;

		++_size;
	}

	void Push_back(const T& value)
	{
		Node<T>* newNode = new Node<T>(value);

		Node<T>* prev = _head->prev;
		Node<T>* next = _head;

		newNode->next = next;
		newNode->prev = prev;

		prev->next = newNode;
		next->prev = newNode;

		++_size;
	}

	Node<T>* At(unsigned int index)
	{
		if (index >= _size)
			return nullptr;

		Node<T>* result = _head->next;
		for (int i = 0; i < index; i++)
		{
			result = result->next;
		}

		return result;
	}

	void Pop_back()
	{
		Node<T>* target = _head->prev;

		if (target == _head)
			return; // ����

		Node<T>* prev = target->prev;
		Node<T>* next = _head;

		prev->next = next;
		next->prev = prev;

		delete target;

		--_size;
	}

	void Pop_Front()
	{
		Node<T>* target = _head->next;

		if (target == _head)
			return; // ����

		Node<T>* prev = _head;
		Node<T>* next = target->next;

		prev->next = next;
		next->prev = prev;

		delete target;

		--_size;
	}

	void Pop_Index(int index)
	{
		Node<T>* target = At(index);

		if (target == nullptr)
			return; // ����

		Node<T>* prev = target->prev;
		Node<T>* next = target->next;

		prev->next = next;
		next->prev = prev;

		delete target;

		--_size;
	}



	T& operator[](unsigned int index)
	{
		if (index >= _size) return _head->data;

		Node<T>* here = _head->next;
		for (int i = 0; i < index; i++)
		{
			here = here->next;
		}

		return here->data;
	}

	void Clear()
	{
		Node<T>* here = _head->next;

		for (int i = 0; i < _size; i++)
		{
			Node<T>* temp = here;
			here = here->next;

			delete temp;
		}

		_head->next = _head;
		_head->prev = _head;
	}

	MyList<T>::Iterator begin() { return MyList<T>::Iterator(_head->next); }
	MyList<T>::Iterator end() { return MyList<T>::Iterator(_head); }

private:
	Node<T>* _head;
	unsigned int _size;
};