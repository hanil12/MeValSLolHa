#include <iostream>
#include <vector>
#include <list>

using namespace std;

#include "MyVector.h"
#include "MyList.h"

class Player
{
	int _hp;
	int _atk;
};

int main()
{
	MyVector<int> v;

	for (int i = 0; i < 1000; i++)
	{
		cout << "Capacity : " << v.Capacity() << endl;
		cout << "Size : " << v.Size() << endl;

		v.Push_back(i);
	}

	for (int i = 0; i < 950; i++)
	{
		v.Pop_back();
	}

	cout << "----------- After Pop ------------" << endl;

	for (int i = 0; i < v.Size(); i++)
	{
		cout << "Capacity : " << v.Capacity() << endl;
		cout << "Size : " << v.Size() << endl;
	}

	MyVector<Player*> myV2;

	for (int i = 0; i < 10; i++)
	{
		myV2.Push_back(new Player());
	}

	return 0;
}