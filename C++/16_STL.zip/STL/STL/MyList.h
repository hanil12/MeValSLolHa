#pragma once

struct Node
{
	Node(const int& data)
		: data(data), next(nullptr), prev(nullptr) {}

	int data;
	Node* next;
	Node* prev;
};

class MyList
{
public:
	MyList()
	: _size(0)
	{
		_head = new Node(0);
		_head->next = _head;
		_head->prev = _head;
	}

	~MyList()
	{
		// ����
	}

	void Push_Front(const int& value)
	{
		Node* newNode = new Node(value);
		// ����...
	}

	void Push_back(const int& value)
	{
		Node* newNode = new Node(value);
		// ����...
	}

	int& operator[](unsigned int index)
	{
		if (index >= _size) return _head->data;

		Node* here = _head->next;
		for (int i = 0; i < index; i++)
		{
			here = here->next;
		}

		return here->data;
	}

private:
	Node* _head;
	unsigned int _size;
};