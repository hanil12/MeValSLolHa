﻿#include <iostream>

using namespace std;

// 함수도 어딘가에 저장되어있지 않을까?

// 함수 포인터 : 타고들어가면... 해당 시그니쳐의 함수가 있을 것이다.
// 함수의 이름은 포인터와 동일하게 동작한다.

// 1. 전역함수를 함수포인터로 넘기는 방법.
// 2. 멤버함수를 함수포인터로 넘기는 방법.

// typedef
typedef unsigned int UINT; // UINT 형을 unsigned int라고 하겠다.
typedef void(*FUNC)(void);

// 함수 포인터 선언
void(*func1)(void);
void(*func2)(int);

void HelloWorld(void)
{
	cout << "Hello World!" << endl;
}

void HelloWorld2(int value)
{
	cout << value << endl;
}

void PrintAge(int value)
{
	cout << "내 나이 : " << value << "입니다." << endl;
}

void CallBack(void(*func)(int), int value)
{
	cout << "함수 포인터!!!" << endl;
	func(value);
}

int main()
{
	UINT temp = 5;
	FUNC func123 = &HelloWorld;

	func1 = &HelloWorld;
	func2 = &HelloWorld2;

	func1();
	func2(5);

	// 콜백방식
	CallBack(&HelloWorld2, 123);
	CallBack(&PrintAge, 32);

	return 0;
}