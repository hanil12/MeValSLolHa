﻿#include <iostream>
#include <vector>
#include <unordered_map>
#include <algorithm>

using namespace std;

// Modern C++ -> C++ 11버전 이후의 C++

// 4. enum class
// 5. 빠른 초기화, 중괄호 초기화
// 6. 범위기반 for문 (range for문)
// 7. auto
// 	// auto : 타입추론
	// 자료형을 컴파일러가 정해준다.
	// - 선언과 동시에 반드시 초기화
	// - 남발하지 말 것
	// - 변수명을 확실히(연관있게) 할 것
	// - auto&

// 8. 람다
// 9. 이동생성자(Shift 개념, 오른값 참조)
// 10. 스마트포인터

// #define SLEEP 12

enum State
{
	SLEEP,
	STURN,
	INVINSIBLE
};

enum EnemyState
{
	E_RAGE,
	E_BLEED,
	E_SLEEP
};

// 암묵적으로 정수형으로 캐스팅 불가
// static_cast를 이용해서 정수형으로 casting

// 1. 장점 : 이름이 겹쳐도 통과
// 2. 단점 : 캐스팅할 때 귀찮다.
enum class PlayerState
{
	SLEEP,
	STURN,
	INVINSIVLE
};

class Player
{
public:
	Player() {}

private:
	int _hp = 0;
};

struct Vector
{
	int x;
	int y;
};

int main()
{
	int temp = EnemyState::E_SLEEP;
	int playerState = static_cast<int>(PlayerState::SLEEP);

	// 중괄호 초기화
	vector<int> v = { 1,2,3,4,5,123,123,23,2,3,1,3,2 };
	int a = { 2 };
	Vector myV = { 1, 2 };

	for (int i = 0; i < v.size(); i++)
	{
		cout << v[i] << endl;
	}

	// 범위기반 for문
	for (int& element : v)
	{
		// element = 10;
		cout << element << endl;
	}

	unordered_map<int, string> um;
	um[0] = "hanil";
	um[1] = "jihun";
	um[2] = "shinwoo";
	um[3] = "Nobody";

	// auto : 타입추론
	// 자료형을 컴파일러가 정해준다.
	// - 선언과 동시에 반드시 초기화
	// - 남발하지 말 것
	// - 변수명을 확실히(연관있게) 할 것
	// - auto&

	auto iter = um.begin();

	for (iter; iter != um.end(); iter++)
	{
		cout << "Key : " << (*iter).first << "  Value : " << (*iter).second << endl;
	}

	for (auto& element : um)
	{
		element.second = "hhh";
		cout << "Key : " << element.first << "  Value : " << element.second << endl;
	}

	// v에서 10보다 작은 얘 찾아서 값출력, 없으면 없습니다 출력
	struct Finder
	{
		bool operator()(const int& element)
		{
			if (element < 10)
				return true;
			return false;
		}
	};

	auto findNum = std::find_if(v.begin(), v.end(), Finder());

	// 람다함수
	// [캡쳐](매개변수) -> (반환자료형) { 실행문 }
	// []()->{}
	int compareNum = 10;

	auto findNum2 = std::find_if(v.begin(), v.end(), [=](const int& element)-> bool
		{
			if (element > compareNum)
				return true;
			return false;
		});

	cout << *findNum2 << endl;

	srand(static_cast<unsigned int>(time(nullptr)));
	vector<Vector> vectorV;
	vectorV.push_back({ rand() %  10, rand() % 10});
	vectorV.push_back({ rand() %  10, rand() % 10});
	vectorV.push_back({ rand() %  10, rand() % 10});
	vectorV.push_back({ rand() %  10, rand() % 10});
	vectorV.push_back({ rand() %  10, rand() % 10});
	vectorV.push_back({ rand() %  10, rand() % 10});

	// 1. x기준으로 오름차순 내림차순으로 정렬
	std::sort(vectorV.begin(), vectorV.end(), [](const Vector& a, const Vector& b) -> bool
		{
			if (a.x > b.x)
				return true;
			return false;
		});
	// 2. vector원소의 길이 순으로 내림차순 정렬해주세요
	std::sort(vectorV.begin(), vectorV.end(), [](const Vector& a, const Vector& b)->bool 
		{
			float aLength = sqrtf(a.x * a.x + a.y * a.y);
			float bLength = sqrtf(b.x * b.x + b.y * b.y);

			if (aLength > bLength)
				return true;
			return false;
		});

	return 0;
}