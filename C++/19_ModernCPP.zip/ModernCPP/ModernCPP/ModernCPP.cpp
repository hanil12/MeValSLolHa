﻿#include <iostream>
#include <vector>

using namespace std;

// Modern C++ -> C++ 11버전 이후의 C++

// 1. friend (은닉성... 희미)
// 2. using
// 3. final, abstract, delete, override
// 4. enum class
// 5. 빠른 초기화, 중괄호 초기화
// 6. auto
// 7. 범위기반 for문 (range for문)
// 8. 람다
// 9. 이동생성자(Shift 개념, 오른값 참조)
// 10. 스마트포인터

// 1. friend
class Player
{
	friend class Inventory;

public:

	virtual void PrintPlayer() abstract; // abstract : 순수가상함수
	virtual void Attack() {} // 가상함수

protected:
	int _hp;
	int _atk;
	int _level;

	class Inventory* _inven;
};

// 3. final, abstract, delete, override
class Knight : public Player
{
public:
	void PrintPlayer() override {}
	// virtual void Attack() final override {} // 내 자식에서는 오버라이드 허용X => 내가 오버라이딩하는 마지막함수다.
	Knight& operator=(const Knight& other) =  delete; // 이 함수 없음.

	// Pet* _pet;
};

class Inventory
{
public:
	void Equip()
	{
		if (_player != nullptr)
		{
			_player->_atk = 10;
		}
	}

private:
	// data...
	Player* _player;
};

// 2. using
// template과 호환이 가능
// typedef는 template과 호환이 불가능
typedef unsigned int UINT;

using int16 = short;
using int32 = int;

template<typename T>
struct Vector2
{
	typedef vector<T> myVectorT; // X
	using HanilV = vector<T>; // O

	myVectorT myTs;

	T x;
	T y;
};

int main()
{
	UINT aInt = 1;

	return 0;
}