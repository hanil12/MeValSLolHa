﻿#include <iostream>
#include <vector>

using namespace std;

// vector
// - 동적배열
// => 동적배열 : 가변배열
// => 정적배열 : 불가변배열

// - 

// list

void PrintVector(vector<int>* v)
{
	for (int i = 0; i < v->size(); i++)
	{
		cout << (*v)[i] << endl;
		(*v)[i] = 1;
	}
}

int main()
{
	vector<int> v;
	v.reserve(1000);
	//v.resize(1000, -1);

	for (int i = 0; i < 1000; i++)
	{
		cout << "Capacity : " << v.capacity() << endl;
		cout << "Size : " << v.size() << endl;

		v.push_back(i);
	}

	PrintVector(&v);


	return 0;
}